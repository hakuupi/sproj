import pandas as pd
import numpy as np

def writeDeriv():
    '''Get first derivative of each segmented csv datafile, and export.'''
    path = '/Users/HAQbook/Documents/GitHub/sproj/second_attempt/data/'
    for piece in range(1,7):
        filename = 'piano01_00'+str(piece)+'_p'
        for performance in range(1,7):
            repo = pd.read_csv(path+filename+str(performance)+'.csv',sep=',',header=0)
            df = repo.diff()
            df.to_csv(path+filename+str(performance)+'_d'+'.csv')

def callDeriv(arrayLST, smoothed=False):
    '''Output list of first derivative arrays of inputted list of arrays'''
    output = []
    for a in arrayLST:
        if smoothed: # optional smoothing by numpy rolling average
            kernel_size = 80
            kernel = np.ones(kernel_size) / kernel_size
            a = np.convolve(a, kernel, mode='same') 
        output.append(np.gradient(a)) #np.diff(a)
    return(output)

